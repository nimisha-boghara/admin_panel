
// sidebar

const allDropdown = document.querySelectorAll('#sidebar .side-dropdown');

allDropdown.forEach(item => {
  const a = item.parentElement.querySelector('a:first-child');
  a.addEventListener('click', function (e) {
    e.preventDefault();

    if (!this.classList.contains('active')) {
      allDropdown.forEach(i => {
        const aLink = i.parentElement.querySelector('a:first-child');

        aLink.classList.remove('active');
        i.classList.remove('show');

      })
    }

    this.classList.toggle('active');
    item.classList.toggle('show');
  })
})



// Toggle-button
// const toggleSidebar = document.querySelector('nav .toggle-sidebar');
// const sidebar = document.getElementById('sidebar');

// toggleSidebar.addEventListener('click', function () {
//     sidebar.classList.toggle('hide')
// })


// sidebar collapse

const toggleSidebar = document.querySelector('nav .toggle-sidebar');
const sidebar = document.getElementById('sidebar');
const allsideDivider = document.querySelectorAll('#sidebar .divider');


if(sidebar.classList.contains('hide')){
  allsideDivider.forEach(item => {
     item.textContent = '-'
  })
} else{
 allsideDivider.forEach(item => {
   item.textContent = item.dataset.text;
 })
}
debugger
toggleSidebar.addEventListener('click', function () {
  sidebar.classList.toggle('hide');


 if(sidebar.classList.contains('hide')){
   allsideDivider.forEach(item => {
      item.textContent = '-'
   })
 } else{
  allsideDivider.forEach(item => {
    item.textContent = item.dataset.text;
  })
 }

})


// Chart-1
let exp = "Math.cos(x)";

// Generate values
const xValues = [];
const yValues = [];
for (let x = 0; x <= 10; x += 0.2) {
  xValues.push(x);
  yValues.push(eval(exp));
}

// Display using Plotly
const data = [{ x: xValues, y: yValues, mode: "markers" }];
const layout = { title: "y = " + exp };
Plotly.newPlot("myPlot", data, layout);



// Chart-2
const xValues1 = ["Italy", "France", "Spain", "USA", "Argentina"];
const yValues1 = [55, 49, 44, 24, 15];
const barColors = [
  "#b91d47",
  "#00aba9",
  "#2b5797",
  "#e8c3b9",
  "#1e7145"
];

new Chart("myChart", {
  type: "doughnut",
  data: {
    labels: xValues1,
    datasets: [{
      backgroundColor: barColors,
      data: yValues1
    }]
  },
  options: {
    title: {
      display: true,
      text: "World Wide Wine Production 2024"
    }
  }
});
