const sidebarToggle = document.querySelector('#sidebar-toggle');
sidebarToggle.addEventListener("click",function(){
    document.querySelector('#sidebar').classList.toggle("collapsed");
})

// Chart-1
let exp = "Math.cos(x)";

// Generate values
const xValues = [];
const yValues = [];
for (let x = 0; x <= 10; x += 0.2) {
  xValues.push(x);
  yValues.push(eval(exp));
}

// Display using Plotly
const data = [{x:xValues, y:yValues, mode:"markers"}];
const layout = {title: "y = " + exp};
Plotly.newPlot("myPlot", data, layout);




// Chart-2
const xValues1 = ["Italy", "France", "Spain", "USA", "Argentina"];
const yValues1 = [55, 49, 44, 24, 15];
const barColors = [
  "#b91d47",
  "#00aba9",
  "#2b5797",
  "#e8c3b9",
  "#1e7145"
];

new Chart("myChart", {
  type: "doughnut",
  data: {
    labels: xValues1,
    datasets: [{
      backgroundColor: barColors,
      data: yValues1
    }]
  },
  options: {
    title: {
      display: true,
      text: "World Wide Wine Production 2024"
    }
  }
});





